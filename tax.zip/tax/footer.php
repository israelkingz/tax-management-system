<!--footer section start-->
			<footer>
			   <p>&copy 2019 Tax Management System. All Rights Reserved | Design  <a href="https://github.com/israelkingz" target="_blank"></a></p>
			</footer>
        <!--footer section end-->

      <!-- main content end-->
   </section>
  
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
</body>
</html>